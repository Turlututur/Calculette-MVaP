Nous avons un script (sh ou bat en fonction de l'os) qui permet de simplifier les commandes trouvables dans aliases.sh/aliases.bat
Un fichiker compil.txt contient les commandes à executer pour compiler et executer le code.

Nous avons été jusqu'à la partie I 